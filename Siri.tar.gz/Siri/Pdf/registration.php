<?php
/**
 * registration componenent
 *
 * @package Siri_Pdf
 * @author  siriammu9000@gmail.com

 */
 
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Siri_Pdf',
    __DIR__
);
